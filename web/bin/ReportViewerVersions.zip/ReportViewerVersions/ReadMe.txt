Copy the dlls for the version of SSRS you need
update SSRS report viewer to match the dll version

I got these by installing report viewer in my system then running the following in command line (using the name of the dll needed, in place of processingobjectmodel):
cd c:\windows\assembly\gac_msil\
xcopy microsoft.reportviewer.processingObjectModel c:\temp /i /h /s /r /y